$(document).ready(function () {

  $('.animation').each(function(){
		
		var waypoint = new Waypoint({
	  	element: this,
	  	handler: function(direction) {
	    	var animation = $(this.element).attr('data-animation');
	    	$(this.element).css('opacity','1');
	    	$(this.element).addClass("animated " + animation);
	  	},
	  	offset: '70%'
	})
});

  jQuery(document).ready(function($) {

   $('.smoothscroll').on('click',function (e) {
	    e.preventDefault();

	    var target = this.hash,
	    $target = $(target);

	    $('html, body').stop().animate({
	        'scrollTop': $target.offset().top
	    }, 1500, 'swing', function () {
	        window.location.hash = target;
	    });
	});
  
});

$(window).scroll(function() {

    if ($(window).scrollTop() > 100) {
        $('.main_nav').addClass('sticky');
    } else {
        $('.main_nav').removeClass('sticky');
    }
});


//Mobile Navigation

$('.mobile-toggle').click(function() {
    if ($('.main_nav').hasClass('open-nav')) {
        $('.main_nav').removeClass('open-nav');
    } else {
        $('.main_nav').addClass('open-nav');
    }
});

$('.main_nav li a').click(function() {
    if ($('.main_nav').hasClass('open-nav')) {
        $('.navigation').removeClass('open-nav');
        $('.main_nav').removeClass('open-nav');
    }
});


$('#main').stellar();

//IIFE
(function () {
  "use strict";
  var menuId;
  function init () {
    menuId = document.getElementById("menu");
    document.addEventListener("scroll",scrollMenu,false);
  }
  function scrollMenu () {
    (document.body.scrollTop > 50) ? 
      menuId.classList.add("scroll"):
      menuId.classList.remove("scroll");
  }
  document.addEventListener("DOMContentLoaded",init,false);
})();

(function (){
  "use strict";
  var mobBtn, topMenu;
  
  function init() {
    mobBtn = document.getElementById("mobile-btn");
  	topMenu = document.getElementById("top-menu");
    mobBtn.addEventListener("click",mobileMenu,false);
  }
  
  function mobileMenu() {
    if(topMenu.classList.contains("mobile-open")) {
       topMenu.classList.remove("mobile-open");
       }else{
        topMenu.classList.add("mobile-open");
       }
    if (mobBtn.classList.contains("hamburger-cross")) {
			mobBtn.classList.remove("hamburger-cross");
		}
		else {
			mobBtn.classList.add("hamburger-cross");
		}
  }
  
  document.addEventListener("DOMContentLoaded",init);
  
})();


$( '.js-input' ).keyup(function() {
  if( $(this).val() ) {
     $(this).addClass('not-empty');
  } else {
     $(this).removeClass('not-empty');
  }
});


/*** for smoothscrolling ***/

$('nav a').smoothScroll();

/*** smooth ***/


$("a[href='#top']").click(function() {
  $("html, body").animate({ scrollTop: 0 }, 2000);
  return false;
});

});

